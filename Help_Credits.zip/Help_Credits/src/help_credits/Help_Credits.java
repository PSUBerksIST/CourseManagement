/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package help_credits;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author pmo5053
 */
public class Help_Credits {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        Credits_JFrame c = new Credits_JFrame();
        c.setVisible(true);
        
        Help_Credits.Names();
}

    
    public static String Names(){
        String textLine;
        String textFile = "";
        
        try {
        FileReader fr = new FileReader("Names.csv");
        BufferedReader reader = new BufferedReader(fr);

        while((textLine=reader.readLine())!=null) {
            String[] textArr = textLine.split(",");
            String value = String.format("%1$-25s %2$-25s", textArr[0], textArr[1]);
            System.out.println(value);
            textFile = textFile + "\n" + value;
        }
        }catch (IOException ioe) {
        System.out.println(ioe);
        System.exit(1);
}        
        System.out.println(textFile);
        return textFile;
}
}